export const environment = {
  production: true,
  apiUrl: 'http://137.131.201.11/api'
};